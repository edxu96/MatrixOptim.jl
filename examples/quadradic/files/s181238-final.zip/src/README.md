
# Julia Scripts for Metsa-Oy Forest Products Supply Chain

Edward J. Xu (<edxu96@outlook.com>)  
Jan 24th, 2020

## How to Run

Change the current directory to `src`, and run the following command:

```
include("main.jl")
```

Package `JuMP` and `Gurobi` are used.

The scripts have been tested in Julia 1.3.
